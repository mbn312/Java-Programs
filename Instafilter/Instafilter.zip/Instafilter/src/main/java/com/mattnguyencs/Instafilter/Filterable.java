package com.mattnguyencs.Instafilter;

public interface Filterable {
	PixelArray filter(PixelArray paramPixelArray);
}
